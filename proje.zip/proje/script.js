
const themeBtn=document.getElementById('themeBtn');
themeBtn.onclick=()=>{
document.body.classList.toggle('dark');
localStorage.setItem('theme',document.body.classList.contains('dark'));
};
if(localStorage.getItem('theme')==='true'){document.body.classList.add('dark');}

document.getElementById('search').addEventListener('keyup',e=>{
let v=e.target.value.toLowerCase();
document.querySelectorAll('.card').forEach(c=>{
c.style.display=c.textContent.toLowerCase().includes(v)?'block':'none';
});
});

function openModal(){document.getElementById('modal').style.display='block';}
function closeModal(){document.getElementById('modal').style.display='none';}

document.getElementById('contactForm').addEventListener('submit',e=>{
e.preventDefault();
let n=name.value.trim();
let m=email.value.trim();
if(!n||!m){alert('Alanları doldur');return;}
localStorage.setItem('formKayit',JSON.stringify({ad:n,email:m}));
openModal();
});

fetch('https://randomuser.me/api/')
.then(r=>r.json())
.then(d=>{
document.getElementById('apiUser').textContent='Örnek Kullanıcı: '+d.results[0].name.first+' '+d.results[0].name.last;
});
